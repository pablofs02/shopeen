<h1>Proyecto de Interfaces de Usuario</h1>

## Miembros del Proyecto
- Pablo Fernández Serrano
- Javier Lanceta Salas
- Javier Leiva Dueñas
- Guillermo Tell González

<h2>Tecnología usada</h2>
<h3>React junto con:</h3>
<ul>
  <li>TypeScript + SWC</li>
  <li>Vite (Para correr y testear la app)</li>
</ul>
